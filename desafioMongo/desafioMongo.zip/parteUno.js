use ecomerce
//db.productos.insertMany([
//    {
//        nombre : "producto 1",
//        precio : 200.5,
//        stock : 5,
//        codigo : 12345
//    },
//    {
//        nombre : "producto 2",
//        precio : 5002.2,
//        stock : 34,
//        codigo : 12415
//    },
//    {
//        nombre : "producto 3",
//        precio : 200.5,
//        stock : 5,
//        codigo : 12345
//    },
//    {
//        nombre : "producto 4",
//        precio : 5002.2,
//        stock : 34,
//        codigo : 12415
//    },
//    {
//        nombre : "producto 5",
//        precio : 200.5,
//        stock : 5,
//        codigo : 12345
//    },
//    {
//        nombre : "producto 6",
//        precio : 5002.2,
//        stock : 34,
//        codigo : 12415
//    },
//    {
//        nombre : "producto 7",
//        precio : 200.5,
//        stock : 5,
//        codigo : 12345
//    },
//    {
//        nombre : "producto 8",
//        precio : 5002.2,
//        stock : 34,
//        codigo : 12415
//    },
//    {
//        nombre : "producto 9",
//        precio : 200.5,
//        stock : 5,
//        codigo : 12345
//    },
//    {
//        nombre : "producto 10",
//        precio : 5002.2,
//        stock : 34,
//        codigo : 12415
//    }
//])


//db.mensajes.insertMany([
//    {
//        mensaje : "hola 1 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 2 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 3 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 4 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 5 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 6 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 7 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 8 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 9 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    },
//    {
//        mensaje : "hola 10 ",
//        fecha : new Date(),
//        email  : "test1@gmail.com"
//        
//    }
//]);
//
//db.productos.find({});
//db.mensajes.find({});

//mongosh
//db.productos.countDocuments();
//db.mensajes.countDocuments();


//db.productos.count();
//db.mensajes.count();



